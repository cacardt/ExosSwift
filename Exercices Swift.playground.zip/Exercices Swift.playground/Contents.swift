import UIKit

// Exercice 1

var range = 1...20
var tab = [Int]()

for _ in range {
    var j: Int = Int.random(in: 1...100)
    tab.append(j)
}
func SommeTab(tab valeurs: [Int]) -> Int {
    var total: Int = 0;
    for i in valeurs {
        total += i
    }
    return total
}

func MoyenneTab(tab valeurs: [Int]) -> Int {
    var somme = SommeTab(tab: valeurs)
    return somme/valeurs.count
}

func MaxValueTab(tab valeurs: [Int]) -> Int {
    var max: Int = 0;
    for nombre in valeurs {
        if nombre > max{
            max = nombre
        }
        
    }
    return max
}
    
func PairElementTab(tab valeurs: [Int]) -> [Int] {
    var pairTab = [Int]();
    for nombre in valeurs {
        if nombre % 2 == 0{
           pairTab.append(nombre)
        }
    }
    return pairTab
}

func TabIntToString(tabInt valeurs: [Int]) -> [String] {
    var tabString = [String]()
    for nombre in valeurs {
        tabString.append("\(nombre)")
    }
    return tabString
}


print("tab", tab)
print("somme de toutes les valeurs du tableau", SommeTab(tab: tab))
print("moyenne de toutes les valeurs du tableau", MoyenneTab(tab: tab))
print("Valeur maximum du tableau", MaxValueTab(tab: tab))
print("tableau des valeurs pairs du tableau", PairElementTab(tab: tab))
print("tableau en String", TabIntToString(tabInt: tab))

// Exercice 2

enum Animal {
    case cat
    case dog
    case elephant
    case giraffe
    case panda
    case penguin
    case cheetah
    case dolphin
    case lion
    case turtle
    
    func AnimalEmoji(){
    }
}
